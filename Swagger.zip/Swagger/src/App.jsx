import React from "react";
import Home from "./Components/Home/Home";
import { Route, Routes } from "react-router-dom";
import Sidebar from "./Components/Sidebar/Sidebar";
import FormPage from "./Components/FormPage/FormPage";


const App = () => {
  return (
    <>
      <Sidebar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/form" element={<FormPage />} />
      </Routes>
    </>
  );
};

export default App;

import { createSlice } from "@reduxjs/toolkit";

export const DataSlice = createSlice({
  name: "DataStorage",
  initialState: {
    allData: [],
  },
  reducers: {
    fetchData: (state, action) => {
      state.allData.push(action.payload);
    },
  },
});

export const { fetchData } = DataSlice.actions;

export default DataSlice.reducer;

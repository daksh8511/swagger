import { configureStore } from "@reduxjs/toolkit";
import DataReducer from "./Slices/DataSlices";

export const store = configureStore({
  reducer: {
    DataSlice: DataReducer,
  },
});

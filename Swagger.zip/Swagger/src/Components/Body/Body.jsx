import React, { useEffect, useState } from "react";
import LoadingScreen from "../LoadingScreen/LoadingScreen";
import BodyTitle from "../BodyTitle/BodyTitle";
import Pagination from "@mui/material/Pagination";

const link = "https://adminapi.reconcilyst.com/config/marketplace/master";

const Body = () => {
  const limit = 7;
  const [data, setData] = useState([]);
  const [isLoading, setLoading] = useState(false);

  const [page, setPage] = useState(1);

  const fetchData = async () => {
    setLoading(true);
    try {
      const response = await fetch(`${link}?page=${page}&limit=${limit}`);
      const mydata = await response.json();
      const final = mydata.body;
      setData(final);
    } catch (err) {
      console.log("error");
    }
    setLoading(false);
  };

  const [rowsPerPage, setRowsPerPage] = useState(limit);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  // const handleNext = () => {
  //   if (page === 0) return page;
  //   setPage(page + 1);
  // };

  // const handlePrev = () => {
  //   if (page === 1) return page;
  //   setPage(page - 1);
  // };

  useEffect(() => {
    fetchData();
  }, [page]);

  return (
    <div className="ms-15 p-4 bg-gray-200">
      <BodyTitle title={"Marketplace"} />
      <div className="titles mt-6 bg-[#9F8FB7] p-4 uppercase text-sm font-bold">
        <ul className="grid grid-cols-6">
          <li>marketplace name</li>
          <li>currency code</li>
          <li>country</li>
          <li>business</li>
          <li>auto</li>
          <li>active</li>
        </ul>
      </div>
      <div className="all_data">
        {isLoading == true ? (
          <LoadingScreen />
        ) : (
          <div className="marketplace_name p-4 grid grid-cols-6">
            <div>
              {data.map((item, i) => {
                return (
                  <span className="block py-3 text-[12px] uppercase">
                    {item.marketplace_name}
                  </span>
                );
              })}
            </div>
            <div>
              {data.map((item, i) => {
                return (
                  <span className="block py-3 text-[12px] uppercase">
                    {item.currency_code}
                  </span>
                );
              })}
            </div>
            <div>
              {data.map((item, i) => {
                return (
                  <span className="block py-3 text-[12px] uppercase">
                    {item.country_code}
                  </span>
                );
              })}
            </div>
            <div>
              {data.map((item, i) => {
                return (
                  <span className="block py-3 text-[12px]">
                    {item.business}
                  </span>
                );
              })}
            </div>
            <div>
              {data.map((item, i) => {
                return (
                  <span className="block py-3 text-[12px]">
                    {item.auto}
                  </span>
                );
              })}
            </div>
            <div>
              {data.map((item, i) => {
                return (
                  <span className="block py-3 text-[12px]">
                    {item.is_active.toString()}
                  </span>
                );
              })}
            </div>
          </div>
        )}
      </div>
      {/* <button className="bg-white mr-5 p-3" onClick={handlePrev} disabled={page === 1}>Prev</button>
      {
        Array(Math.floor(64/limit)).fill(null).map((item,index)=>{
          return(
            <>
            <button className="bg-white p-3 mr-5 cursor-pointer" onClick={() => setPage(index + 1)}>{index + 1}</button>
            </>
          )
        })
      }
      <button className="bg-white mr-5 p-3" onClick={handleNext} disabled={page === Math.floor(64/limit)}>Next</button> */}

      <Pagination count={10} showFirstButton showLastButton />
    </div>
  );
};

export default Body;

import React from "react";
import { MdDashboard, MdOutlineSettingsInputComponent } from "react-icons/md";
import { SiCoinmarketcap } from "react-icons/si";

const Sidebar = () => {
  return (
    <div className="bg-[#041433] p-2 ps-3 fixed overflow-hidden h-full duration-300 w-[60px] hover:w-[250px] hover:overflow-y-scroll z-10">
      <div className="menu flex relative hover:bg-gray-500 mb-8 hover:text-black items-center hover:cursor-pointer">
        <MdDashboard className="text-white text-3xl ms-1" />
        <h3 className="ms-12 text-white font-semibold text-sm absolute w-screen">Dashboard</h3>
      </div>
      <div className="menu flex relative hover:bg-gray-500 mb-8 hover:text-black items-center hover:cursor-pointer">
        <SiCoinmarketcap className="text-white text-3xl ms-1" />
        <h3 className="ms-12 text-white font-semibold text-sm absolute w-screen">Report Config</h3>
      </div>
      <div className="menu flex relative hover:bg-gray-500 mb-8 hover:text-black items-center hover:cursor-pointer">
        <SiCoinmarketcap className="text-white text-3xl ms-1" />
        <h3 className="ms-12 text-white font-semibold text-sm absolute w-screen">Funnel Config</h3>
      </div>

      <div className="menu flex relative hover:bg-gray-500 mb-8 hover:text-black items-center hover:cursor-pointer">
        <MdOutlineSettingsInputComponent className="text-white text-3xl ms-1" />
        <h3 className="ms-12 text-white font-semibold text-sm absolute w-screen">Marketplace Master</h3>
      </div>

      <div className="menu flex relative hover:bg-gray-500 mb-8 hover:text-black items-center hover:cursor-pointer">
        <MdOutlineSettingsInputComponent className="text-white text-3xl ms-1" />
        <h3 className="ms-12 text-white font-semibold text-sm absolute w-screen">Markterplace Details</h3>
      </div>

      <div className="menu flex relative hover:bg-gray-500 mb-8 hover:text-black items-center hover:cursor-pointer">
        <MdOutlineSettingsInputComponent className="text-white text-3xl ms-1" />
        <h3 className="ms-12 text-white font-semibold text-sm absolute w-screen">Scenario Master</h3>
      </div>

      <div className="menu flex relative hover:bg-gray-500 mb-8 hover:text-black items-center hover:cursor-pointer">
        <MdOutlineSettingsInputComponent className="text-white text-3xl ms-1" />
        <h3 className="ms-12 text-white font-semibold text-sm absolute w-screen">Scenario Details</h3>
      </div>

      <div className="menu flex relative hover:bg-gray-500 mb-8 hover:text-black items-center hover:cursor-pointer">
        <MdOutlineSettingsInputComponent className="text-white text-3xl ms-1" />
        <h3 className="ms-12 text-white font-semibold text-sm absolute w-screen">Scrapy Login</h3>
      </div>

      <div className="menu flex relative hover:bg-gray-500 mb-8 hover:text-black items-center hover:cursor-pointer">
        <MdOutlineSettingsInputComponent className="text-white text-3xl ms-1" />
        <h3 className="ms-12 text-white font-semibold text-sm absolute w-screen">Scrapy Count</h3>
      </div>
    </div>
  );
};

export default Sidebar;

import React from "react";

const Pagination = ({ totalPost, postPerPage, setCurrentPage, data }) => {
  const pages = [];

  for (let i = 0; i <= Math.ceil(totalPost / postPerPage); i++) {
    pages.push(i + 1);
  }

  return (
    <div>
      {pages.map((pages, index) => {
        return (
          <button
            onClick={() => setCurrentPage(pages)}
            key={index}
            className="bg-white me-4 p-3 cursor-pointer"
          >
            {pages}
          </button>
        );
      })}
    </div>
  );
};

export default Pagination;

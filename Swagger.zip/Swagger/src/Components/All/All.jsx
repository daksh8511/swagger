import React from "react";
import BodyTitle from "../BodyTitle/BodyTitle";

const All = () => {
  return (
    <div>
      <BodyTitle title={"All"} />
    </div>
  );
};

export default All;

import React from 'react'
import preloader from '/assets/preloader.gif'

const LoadingScreen = () => {
  return (
    <div>
        <img src={preloader} className='m-auto mt-10' alt="" />
    </div>
  )
}

export default LoadingScreen
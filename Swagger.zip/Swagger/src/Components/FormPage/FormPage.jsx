import React, { useState } from "react";
import Select from "react-select";
import "./FormPage.css";
import axios from "axios";
import { Link } from "react-router-dom";

const link = "https://adminapi.reconcilyst.com/config/marketplace/master";

const FormPage = () => {
  const businessObj = [
    { value: 1, label: "B2B" },
    { value: 2, label: "B2C" },
  ];

  const autoObj = [
    { value: 0, label: "false" },
    { value: 1, label: "true" },
  ];
  const statusObj = [
    { value: 0, label: "false" },
    { value: 1, label: "true" },
  ];
  const activeObj = [
    { value: true, label: "true" },
    { value: false, label: "false" },
  ];
  const loginWithApiObj = [
    { value: true, label: "true" },
    { value: false, label: "false" },
  ];
  const loginwithScarpObj = [
    { value: true, label: "true" },
    { value: false, label: "false" },
  ];
  const typeObj = [
    { value: "MP", label: "MP" },
    { value: "OMS", label: "OMS" },
    { value: "3PL", label: "3PL" },
  ];

  const [marketplaceID, setMarketplaceID] = useState(0);
  const [marketplaceName, setMarketplaceName] = useState("");
  const [currencyCode, setcurrencyCode] = useState("");
  const [countryCode, setcountryCode] = useState("");
  const [business, setBusiness] = useState("");
  const [auto, setAuto] = useState("");
  const [status, setStatus] = useState("");
  const [active, setActive] = useState("");
  const [loginwithapi, setLoginWithAPI] = useState("");
  const [loginwithScrap, setLoginWithScrap] = useState("");
  const [type, setType] = useState("");
  const [faviconUrl, setFaviconUrl] = useState("");
  const [logoUrl, setLogoUrl] = useState("");

  const data = {
    marketplace_id: Number(marketplaceID),
    marketplace_name: marketplaceName,
    currency_code: currencyCode,
    country: countryCode,
    business: business.value,
    auto: auto.value,
    status: status.value,
    is_active: active.value,
    login_with_api: loginwithapi.value,
    login_with_scrapy: loginwithScrap.value,
    type: type.value,
    favicon_url: faviconUrl,
    logo_url: logoUrl,
  };

  const handleSubmit = (e) => {
    e.preventDefault();
  };

  const handleClick = () => {
    axios
      .post(link, data)
      .then((response) => console.log(response))
      .catch((err) => console.log(err));
  };

  return (
    <div className="ms-15 p-4 bg-gray-200">
      <div className="title">
        <h2 className="font-semibold text-2xl">Form</h2>
      </div>
      <form
        action=""
        onSubmit={handleSubmit}
        className="form grid grid-cols-3 gap-4"
      >
        <div className="marketplaceID">
          <label>Marketplace ID</label>
          <input
            type="number"
            placeholder="Marketplace ID"
            value={marketplaceID}
            className="w-full"
            onChange={(e) => setMarketplaceID(e.target.value)}
          />
        </div>
        <div className="marketplaceName">
          <label>Marketplace Name</label>
          <input
            type="text"
            placeholder="Marketplace Name"
            className="w-full"
            value={marketplaceName}
            onChange={(e) => setMarketplaceName(e.target.value)}
          />
        </div>
        <div className="currencyCode">
          <label>Currency Code</label>
          <input
            type="text"
            placeholder="Currency Code"
            value={currencyCode}
            className="placeholder:capitalize uppercase w-full"
            onChange={(e) => setcurrencyCode(e.target.value)}
          />
        </div>
        <div className="country">
          <label>Country Code</label>
          <input
            type="text"
            placeholder="Country Code"
            value={countryCode}
            className="placeholder:capitalize uppercase w-full"
            onChange={(e) => setcountryCode(e.target.value)}
          />
        </div>
        <div className="business">
          <label>Business</label>
          <Select options={businessObj} onChange={setBusiness} />
        </div>
        <div className="auto">
          <label>Auto</label>
          <Select options={autoObj} onChange={setAuto} />
        </div>
        <div className="status">
          <label>Status</label>
          <Select options={statusObj} onChange={setStatus} />
        </div>
        <div className="isActive">
          <label>Is Active?</label>
          <Select options={activeObj} onChange={setActive} />
        </div>
        <div className="loginwithapi">
          <label>Login With API</label>
          <Select options={loginWithApiObj} onChange={setLoginWithAPI} />
        </div>
        <div className="loginwithScrap">
          <label>Login With Scrapy</label>
          <Select options={loginwithScarpObj} onChange={setLoginWithScrap} />
        </div>
        <div className="type">
          <label>Type</label>
          <Select options={typeObj} onChange={setType} />
        </div>
        <div className="faviconUrl">
          <label>Favicon URL</label>
          <input
            type="text"
            placeholder="Favicon URL"
            className="w-full"
            value={faviconUrl}
            onChange={(e) => setFaviconUrl(e.target.value)}
          />
        </div>
        <div className="logoUrl">
          <label>Logo URL</label>
          <input
            type="text"
            placeholder="Logo URL"
            value={logoUrl}
            className="w-full"
            onChange={(e) => setLogoUrl(e.target.value)}
          />
        </div>
      </form>
      <div className="mt-6 w-full bg-gray-500 hover:bg-gray-400 text-center p-2">
        <Link
          to="/"
          onClick={handleClick}
          className=" w-full  text-white font-semibold "
        >
          Click
        </Link>
      </div>
    </div>
  );
};

export default FormPage;

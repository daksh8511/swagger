import React from "react";
import Body from "../Body/Body";
import BodyTitle from "../BodyTitle/BodyTitle";

const Home = () => {
  return (
    <div>
      <Body />
    </div>
  );
};

export default Home;

import React from "react";
import { Link } from "react-router-dom";

const BodyTitle = ({ title }) => {
  return (
    <div className="flex items-center justify-between ">
      <h2 className="font-semibold text-2xl">{title}</h2>
      <Link to='/form'>
        <button className="bg-gray-400 cursor-pointer hover:bg-gray-500 text-white px-5 py-1 rounded-full">
          + ADD
        </button>
      </Link>
    </div>
  );
};

export default BodyTitle;
